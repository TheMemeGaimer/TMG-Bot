'use client';

import { useState } from 'react';

function Select({ label, value, onChange, options, placeholder }) {
  return (
    <label className="block">
      <span className="text-sm font-medium">{label}</span>
      <select
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value || null)}
        className="mt-1.5 w-full rounded border border-line bg-raised px-3 py-2 text-sm outline-none focus:border-signal"
      >
        <option value="">{placeholder}</option>
        {options.map((opt) => (
          <option key={opt.id} value={opt.id}>
            {opt.name}
          </option>
        ))}
      </select>
    </label>
  );
}

export default function SettingsForm({ guildId, meta, initialSettings }) {
  const [settings, setSettings] = useState(initialSettings);
  const [status, setStatus] = useState('idle'); // idle | saving | saved | error

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus('saving');

    try {
      const res = await fetch(`/api/guilds/${guildId}/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          log_channel_id: settings.log_channel_id,
          welcome_channel_id: settings.welcome_channel_id,
          welcome_message: settings.welcome_message,
          mute_role_id: settings.mute_role_id,
        }),
      });

      if (!res.ok) throw new Error('save failed');
      setStatus('saved');
      setTimeout(() => setStatus('idle'), 2000);
    } catch (err) {
      setStatus('error');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-lg space-y-6">
      <Select
        label="Canale dei log"
        value={settings.log_channel_id}
        onChange={(v) => setSettings((s) => ({ ...s, log_channel_id: v }))}
        options={meta.channels}
        placeholder="Nessun canale selezionato"
      />

      <Select
        label="Canale di benvenuto"
        value={settings.welcome_channel_id}
        onChange={(v) => setSettings((s) => ({ ...s, welcome_channel_id: v }))}
        options={meta.channels}
        placeholder="Nessun canale selezionato"
      />

      <label className="block">
        <span className="text-sm font-medium">Messaggio di benvenuto</span>
        <input
          type="text"
          value={settings.welcome_message ?? ''}
          onChange={(e) => setSettings((s) => ({ ...s, welcome_message: e.target.value }))}
          placeholder="Benvenuto/a {utente}! 👋"
          className="mt-1.5 w-full rounded border border-line bg-raised px-3 py-2 text-sm outline-none focus:border-signal"
        />
        <span className="mt-1 block text-xs text-mute">
          Usa {'{utente}'} per menzionare il nuovo membro.
        </span>
      </label>

      <Select
        label="Ruolo mute di riserva"
        value={settings.mute_role_id}
        onChange={(v) => setSettings((s) => ({ ...s, mute_role_id: v }))}
        options={meta.roles}
        placeholder="Nessun ruolo selezionato"
      />

      <div className="flex items-center gap-3">
        <button
          type="submit"
          disabled={status === 'saving'}
          className="rounded bg-signal px-5 py-2 text-sm font-medium text-ink hover:brightness-110 disabled:opacity-60"
        >
          {status === 'saving' ? 'Salvataggio...' : 'Salva impostazioni'}
        </button>
        {status === 'saved' && <span className="text-sm text-ok">Impostazioni salvate.</span>}
        {status === 'error' && (
          <span className="text-sm text-danger">Errore nel salvataggio. Riprova.</span>
        )}
      </div>
    </form>
  );
}
