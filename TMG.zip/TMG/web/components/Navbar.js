'use client';

import Link from 'next/link';
import { useSession, signIn, signOut } from 'next-auth/react';

export default function Navbar() {
  const { data: session, status } = useSession();

  return (
    <header className="border-b border-line">
      <div className="container-tmg flex h-16 items-center justify-between">
        <Link href="/" className="font-display text-lg font-700 tracking-tight">
          TMG
        </Link>

        <nav className="hidden items-center gap-8 text-sm text-mute sm:flex">
          <Link href="/#funzionalita" className="hover:text-paper">
            Funzionalità
          </Link>
          <Link href="/#come-funziona" className="hover:text-paper">
            Come funziona
          </Link>
          <Link href="/dashboard" className="hover:text-paper">
            Dashboard
          </Link>
          <a
            href="https://github.com/"
            target="_blank"
            rel="noreferrer"
            className="hover:text-paper"
          >
            GitHub
          </a>
        </nav>

        {status === 'authenticated' ? (
          <div className="flex items-center gap-3">
            <span className="hidden text-sm text-mute sm:inline">{session.user.name}</span>
            <button
              onClick={() => signOut()}
              className="rounded border border-line px-3 py-1.5 text-sm hover:border-mute"
            >
              Esci
            </button>
          </div>
        ) : (
          <button
            onClick={() => signIn('discord')}
            className="rounded bg-paper px-4 py-1.5 text-sm font-medium text-ink hover:bg-white"
          >
            Accedi
          </button>
        )}
      </div>
    </header>
  );
}
