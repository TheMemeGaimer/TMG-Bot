'use client';

import { useEffect, useState } from 'react';

const SCRIPTED_LINES = [
  { tag: 'MOD', text: 'ban  utente_82  →  spam pubblicitario ripetuto', tone: 'danger' },
  { tag: 'LOG', text: 'messaggio eliminato in #generale da moderatore_lu', tone: 'mute' },
  { tag: 'MOD', text: 'timeout  nuovo_account_3  10m  →  linguaggio offensivo', tone: 'signal' },
  { tag: 'LOG', text: 'nuovo membro: player_kk (account creato 2 giorni fa)', tone: 'ok' },
  { tag: 'MOD', text: 'warn  ospite_22  →  1/3 avvertimenti', tone: 'signal' },
  { tag: 'LOG', text: 'messaggio modificato in #supporto', tone: 'mute' },
  { tag: 'MOD', text: 'kick  bot_sospetto  →  account non verificato', tone: 'danger' },
];

const TONE_CLASSES = {
  danger: 'text-danger',
  signal: 'text-signal',
  ok: 'text-ok',
  mute: 'text-mute',
};

export default function ConsoleFeed() {
  const [lines, setLines] = useState(SCRIPTED_LINES.slice(0, 3));

  useEffect(() => {
    let i = 3;
    const interval = setInterval(() => {
      setLines((prev) => {
        const next = [...prev, SCRIPTED_LINES[i % SCRIPTED_LINES.length]];
        i += 1;
        return next.slice(-6);
      });
    }, 2600);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="rounded border border-line bg-raised shadow-[0_0_0_1px_rgba(255,255,255,0.02)]">
      <div className="flex items-center gap-2 border-b border-line px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-ok" />
        <span className="font-mono text-xs text-mute">#log-moderazione</span>
      </div>
      <div className="h-64 space-y-2 overflow-hidden p-4 font-mono text-[13px] leading-relaxed">
        {lines.map((line, idx) => (
          <div key={`${line.text}-${idx}`} className="flex gap-2 text-mute">
            <span className={`shrink-0 ${TONE_CLASSES[line.tone]}`}>[{line.tag}]</span>
            <span className="text-paper/80">{line.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
