export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="container-tmg flex flex-col items-start justify-between gap-4 py-10 text-sm text-mute sm:flex-row sm:items-center">
        <p>TMG è open source, sotto licenza MIT.</p>
        <div className="flex gap-6">
          <a href="https://github.com/" target="_blank" rel="noreferrer" className="hover:text-paper">
            Codice sorgente
          </a>
          <a href="/#funzionalita" className="hover:text-paper">
            Funzionalità
          </a>
        </div>
      </div>
    </footer>
  );
}
