import Image from 'next/image';
import Link from 'next/link';
import { buildInviteUrl } from '@/lib/discord';

export default function GuildCard({ guild }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-line py-4 last:border-b-0">
      <div className="flex items-center gap-3">
        {guild.icon ? (
          <Image src={guild.icon} alt="" width={40} height={40} className="rounded-full" />
        ) : (
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-overlay font-display text-sm">
            {guild.name.slice(0, 2).toUpperCase()}
          </div>
        )}
        <span className="font-medium">{guild.name}</span>
      </div>

      {guild.botPresent ? (
        <Link
          href={`/dashboard/${guild.id}`}
          className="rounded border border-line px-4 py-1.5 text-sm hover:border-mute"
        >
          Gestisci
        </Link>
      ) : (
        <a
          href={buildInviteUrl(guild.id)}
          className="rounded bg-signal px-4 py-1.5 text-sm font-medium text-ink hover:brightness-110"
        >
          Aggiungi bot
        </a>
      )}
    </div>
  );
}
