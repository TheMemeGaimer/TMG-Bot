import { Space_Grotesk, Inter, IBM_Plex_Mono } from 'next/font/google';
import Providers from '@/components/Providers';
import './globals.css';

const display = Space_Grotesk({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-display',
});

const body = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-body',
});

const mono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-mono',
});

export const metadata = {
  title: 'TMG — bot Discord di moderazione',
  description:
    'TMG tiene il tuo server Discord sotto controllo: moderazione, log dettagliati e una dashboard web per gestire tutto senza toccare un comando.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="it" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body className="font-sans">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
