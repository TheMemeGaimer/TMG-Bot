import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ConsoleFeed from '@/components/ConsoleFeed';

const COMMANDS = [
  { name: '/ban', desc: 'Banna un utente, con possibilità di eliminarne i messaggi recenti.' },
  { name: '/kick', desc: 'Espelle un utente dal server.' },
  { name: '/timeout', desc: 'Silenzia temporaneamente un utente per un numero di minuti a scelta.' },
  { name: '/warn', desc: 'Registra un avvertimento collegato allo storico dell\'utente.' },
  { name: '/purge', desc: 'Elimina in blocco gli ultimi messaggi di un canale, anche filtrando per autore.' },
  { name: '/say', desc: 'Fa scrivere un messaggio al bot in qualsiasi canale.' },
  { name: '/embed', desc: 'Invia un embed personalizzato con titolo, testo e colore a scelta.' },
  { name: '/settings', desc: 'Mostra la configurazione attuale del server, sincronizzata con la dashboard.' },
];

const STEPS = [
  {
    title: 'Aggiungi TMG al tuo server',
    desc: 'Un solo clic ti porta alla schermata di autorizzazione di Discord: scegli il server e conferma i permessi.',
  },
  {
    title: 'Configura dalla dashboard',
    desc: 'Accedi con Discord, scegli il canale dei log, il messaggio di benvenuto e il ruolo mute — niente comandi da ricordare a memoria.',
  },
  {
    title: 'TMG modera in automatico',
    desc: 'Ban, timeout, messaggi eliminati e nuovi membri finiscono tutti nel canale di log, in tempo reale.',
  },
];

export default function HomePage() {
  return (
    <>
      <Navbar />

      <main>
        <section className="container-tmg grid gap-12 py-20 lg:grid-cols-2 lg:items-center lg:py-28">
          <div>
            <h1 className="max-w-md text-4xl font-600 leading-[1.1] tracking-tight sm:text-5xl">
              TMG tiene il tuo server sotto controllo.
            </h1>
            <p className="mt-6 max-w-sm text-base leading-relaxed text-mute">
              Moderazione, log dettagliati e gestione del server in un bot open source,
              con una dashboard web per configurarlo senza toccare uno slash command.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="/api/auth/signin/discord"
                className="rounded bg-signal px-5 py-2.5 text-sm font-medium text-ink hover:brightness-110"
              >
                Aggiungi al server
              </a>
              <a
                href="https://github.com/"
                target="_blank"
                rel="noreferrer"
                className="rounded border border-line px-5 py-2.5 text-sm font-medium hover:border-mute"
              >
                Vedi il codice su GitHub
              </a>
            </div>
          </div>

          <ConsoleFeed />
        </section>

        <section id="funzionalita" className="border-t border-line py-20">
          <div className="container-tmg">
            <h2 className="max-w-md text-2xl font-600 tracking-tight sm:text-3xl">
              Ogni comando fa esattamente una cosa.
            </h2>
            <p className="mt-3 max-w-prose text-mute">
              Niente menu nascosti: gli slash command di TMG sono diretti e prevedibili,
              e ogni azione di moderazione viene registrata automaticamente.
            </p>

            <div className="mt-10 divide-y divide-line border-y border-line">
              {COMMANDS.map((cmd) => (
                <div key={cmd.name} className="grid gap-1 py-4 sm:grid-cols-[140px_1fr] sm:gap-6">
                  <code className="font-mono text-sm text-signal">{cmd.name}</code>
                  <p className="text-sm text-mute">{cmd.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="come-funziona" className="border-t border-line py-20">
          <div className="container-tmg">
            <h2 className="max-w-md text-2xl font-600 tracking-tight sm:text-3xl">
              Da zero a server moderato in tre passaggi.
            </h2>

            <div className="mt-10 grid gap-8 sm:grid-cols-3">
              {STEPS.map((step, idx) => (
                <div key={step.title}>
                  <span className="font-mono text-sm text-signal">{`0${idx + 1}`}</span>
                  <h3 className="mt-3 text-lg font-600">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-mute">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="border-t border-line py-20">
          <div className="container-tmg flex flex-col items-start gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-2xl font-600 tracking-tight">Pronto a provarlo?</h2>
              <p className="mt-2 text-mute">Aggiungilo al tuo server in meno di un minuto.</p>
            </div>
            <a
              href="/api/auth/signin/discord"
              className="shrink-0 rounded bg-signal px-5 py-2.5 text-sm font-medium text-ink hover:brightness-110"
            >
              Aggiungi al server
            </a>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
