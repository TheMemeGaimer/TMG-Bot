import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';
import { botApi } from '@/lib/botApi';

export async function GET(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Non autenticato.' }, { status: 401 });

  try {
    const meta = await botApi.getGuildMeta(params.guildId);
    return NextResponse.json(meta);
  } catch (err) {
    console.error('[api/guilds/meta]', err);
    return NextResponse.json({ error: 'Il bot non è raggiungibile o non è in questo server.' }, { status: 502 });
  }
}
