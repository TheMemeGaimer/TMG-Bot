import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';
import { fetchManageableGuilds } from '@/lib/discord';
import { botApi } from '@/lib/botApi';

async function assertCanManage(session, guildId) {
  const guilds = await fetchManageableGuilds(session.accessToken);
  return guilds.some((g) => g.id === guildId);
}

export async function GET(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Non autenticato.' }, { status: 401 });

  if (!(await assertCanManage(session, params.guildId))) {
    return NextResponse.json({ error: 'Non hai i permessi su questo server.' }, { status: 403 });
  }

  const settings = await botApi.getSettings(params.guildId);
  return NextResponse.json(settings);
}

export async function POST(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Non autenticato.' }, { status: 401 });

  if (!(await assertCanManage(session, params.guildId))) {
    return NextResponse.json({ error: 'Non hai i permessi su questo server.' }, { status: 403 });
  }

  const body = await request.json();
  const updated = await botApi.updateSettings(params.guildId, body);
  return NextResponse.json(updated);
}
