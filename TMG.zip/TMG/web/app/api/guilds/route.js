import { getServerSession } from 'next-auth';
import { NextResponse } from 'next/server';
import { authOptions } from '@/lib/auth';
import { fetchManageableGuilds } from '@/lib/discord';
import { botApi } from '@/lib/botApi';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Non autenticato.' }, { status: 401 });

  try {
    const [manageable, botGuilds] = await Promise.all([
      fetchManageableGuilds(session.accessToken),
      botApi.getGuilds().catch(() => []), // se il bot è offline mostriamo comunque i server
    ]);

    const botGuildIds = new Set(botGuilds.map((g) => g.id));

    const guilds = manageable.map((g) => ({
      ...g,
      botPresent: botGuildIds.has(g.id),
    }));

    return NextResponse.json(guilds);
  } catch (err) {
    console.error('[api/guilds]', err);
    return NextResponse.json({ error: 'Impossibile recuperare i server.' }, { status: 500 });
  }
}
