import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { fetchManageableGuilds } from '@/lib/discord';
import { botApi } from '@/lib/botApi';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import GuildCard from '@/components/GuildCard';

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    return (
      <>
        <Navbar />
        <main className="container-tmg py-24 text-center">
          <h1 className="text-2xl font-600">Accedi per gestire i tuoi server</h1>
          <p className="mt-2 text-mute">Ti serve un login con Discord per vedere la dashboard.</p>
          <a
            href="/api/auth/signin/discord"
            className="mt-6 inline-block rounded bg-signal px-5 py-2.5 text-sm font-medium text-ink hover:brightness-110"
          >
            Accedi con Discord
          </a>
        </main>
        <Footer />
      </>
    );
  }

  let guilds = [];
  let error = null;

  try {
    const manageable = await fetchManageableGuilds(session.accessToken);
    const botGuilds = await botApi.getGuilds().catch(() => []);
    const botGuildIds = new Set(botGuilds.map((g) => g.id));
    guilds = manageable.map((g) => ({ ...g, botPresent: botGuildIds.has(g.id) }));
  } catch (err) {
    console.error('[dashboard]', err);
    error = 'Non riesco a contattare Discord o il bot in questo momento.';
  }

  return (
    <>
      <Navbar />
      <main className="container-tmg py-16">
        <h1 className="text-2xl font-600 tracking-tight">I tuoi server</h1>
        <p className="mt-2 text-mute">
          Solo i server dove hai il permesso "Gestisci server" compaiono qui.
        </p>

        {error && <p className="mt-8 text-sm text-danger">{error}</p>}

        {!error && guilds.length === 0 && (
          <p className="mt-8 text-sm text-mute">
            Non risultano server gestibili con questo account.
          </p>
        )}

        {!error && guilds.length > 0 && (
          <div className="mt-8 max-w-xl">
            {guilds.map((g) => (
              <GuildCard key={g.id} guild={g} />
            ))}
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}
