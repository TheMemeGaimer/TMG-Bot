import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { fetchManageableGuilds } from '@/lib/discord';
import { botApi } from '@/lib/botApi';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import SettingsForm from '@/components/SettingsForm';

export default async function GuildSettingsPage({ params }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    return (
      <>
        <Navbar />
        <main className="container-tmg py-24 text-center">
          <h1 className="text-2xl font-600">Accedi per continuare</h1>
        </main>
        <Footer />
      </>
    );
  }

  const manageable = await fetchManageableGuilds(session.accessToken);
  const canManage = manageable.some((g) => g.id === params.guildId);

  if (!canManage) {
    return (
      <>
        <Navbar />
        <main className="container-tmg py-24 text-center">
          <h1 className="text-2xl font-600">Accesso negato</h1>
          <p className="mt-2 text-mute">Non hai i permessi di gestione su questo server.</p>
        </main>
        <Footer />
      </>
    );
  }

  let meta;
  let settings;
  let error = null;

  try {
    [meta, settings] = await Promise.all([
      botApi.getGuildMeta(params.guildId),
      botApi.getSettings(params.guildId),
    ]);
  } catch (err) {
    error = 'Il bot non risulta connesso a questo server in questo momento.';
  }

  return (
    <>
      <Navbar />
      <main className="container-tmg py-16">
        <h1 className="text-2xl font-600 tracking-tight">{meta?.name ?? 'Impostazioni server'}</h1>
        <p className="mt-2 text-mute">
          Le modifiche qui sono immediate: non serve rilanciare il bot.
        </p>

        {error ? (
          <p className="mt-8 text-sm text-danger">{error}</p>
        ) : (
          <div className="mt-10">
            <SettingsForm guildId={params.guildId} meta={meta} initialSettings={settings} />
          </div>
        )}
      </main>
      <Footer />
    </>
  );
}
