/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#10131A',
        raised: '#171B24',
        overlay: '#1E2330',
        line: '#262B37',
        paper: '#ECEEF3',
        mute: '#8891A3',
        signal: '#FFB020',
        'signal-soft': 'rgba(255, 176, 32, 0.12)',
        danger: '#E5484D',
        ok: '#3ECF8E',
      },
      fontFamily: {
        display: ['var(--font-display)', 'sans-serif'],
        sans: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      borderRadius: {
        DEFAULT: '6px',
      },
      maxWidth: {
        prose: '68ch',
      },
    },
  },
  plugins: [],
};
