const { getGuildSettings } = require('./database');

/**
 * Invia un embed nel canale di log configurato per la guild, se presente.
 */
async function logAction(client, guildId, embed) {
  const settings = getGuildSettings(guildId);
  if (!settings.log_channel_id) return;

  try {
    const channel = await client.channels.fetch(settings.log_channel_id);
    if (channel?.isTextBased()) {
      await channel.send({ embeds: [embed] });
    }
  } catch (err) {
    console.warn(`[logger] impossibile scrivere nel canale di log della guild ${guildId}:`, err.message);
  }
}

module.exports = { logAction };
