const { EmbedBuilder } = require('discord.js');
const config = require('../config');

function baseEmbed() {
  return new EmbedBuilder().setFooter({ text: 'TMG' }).setTimestamp();
}

function buildModEmbed({ action, target, moderator, reason, color, extra }) {
  const embed = baseEmbed()
    .setTitle(`${action}`)
    .setColor(color ?? config.brand.color)
    .addFields(
      { name: 'Utente', value: `${target} (${target.id})`, inline: true },
      { name: 'Moderatore', value: `${moderator}`, inline: true },
      { name: 'Motivo', value: reason || 'Nessun motivo specificato' }
    );

  if (extra) embed.addFields(extra);
  return embed;
}

function buildLogEmbed({ title, description, color, fields }) {
  const embed = baseEmbed().setTitle(title).setColor(color ?? config.brand.color);
  if (description) embed.setDescription(description);
  if (fields) embed.addFields(fields);
  return embed;
}

module.exports = { buildModEmbed, buildLogEmbed };
