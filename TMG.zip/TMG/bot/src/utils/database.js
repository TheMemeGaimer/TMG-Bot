const Database = require('better-sqlite3');
const path = require('node:path');
const fs = require('node:fs');
const config = require('../config');

let db;

function initDatabase() {
  const resolvedPath = path.resolve(process.cwd(), config.databasePath);
  fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });

  db = new Database(resolvedPath);
  db.pragma('journal_mode = WAL');

  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_settings (
      guild_id TEXT PRIMARY KEY,
      log_channel_id TEXT,
      welcome_channel_id TEXT,
      welcome_message TEXT,
      mute_role_id TEXT,
      prefix TEXT DEFAULT '!'
    );

    CREATE TABLE IF NOT EXISTS warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      moderator_id TEXT NOT NULL,
      reason TEXT,
      created_at INTEGER NOT NULL
    );
  `);

  console.log(`[database] pronto — ${resolvedPath}`);
  return db;
}

function getDb() {
  if (!db) throw new Error('Database non inizializzato: chiama initDatabase() prima.');
  return db;
}

function getGuildSettings(guildId) {
  const row = getDb()
    .prepare('SELECT * FROM guild_settings WHERE guild_id = ?')
    .get(guildId);

  return (
    row || {
      guild_id: guildId,
      log_channel_id: null,
      welcome_channel_id: null,
      welcome_message: null,
      mute_role_id: null,
      prefix: '!',
    }
  );
}

function upsertGuildSettings(guildId, partialSettings) {
  const current = getGuildSettings(guildId);
  const merged = { ...current, ...partialSettings, guild_id: guildId };

  getDb()
    .prepare(
      `INSERT INTO guild_settings (guild_id, log_channel_id, welcome_channel_id, welcome_message, mute_role_id, prefix)
       VALUES (@guild_id, @log_channel_id, @welcome_channel_id, @welcome_message, @mute_role_id, @prefix)
       ON CONFLICT(guild_id) DO UPDATE SET
         log_channel_id = excluded.log_channel_id,
         welcome_channel_id = excluded.welcome_channel_id,
         welcome_message = excluded.welcome_message,
         mute_role_id = excluded.mute_role_id,
         prefix = excluded.prefix`
    )
    .run(merged);

  return merged;
}

function addWarning(guildId, userId, moderatorId, reason) {
  const info = getDb()
    .prepare(
      `INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(guildId, userId, moderatorId, reason, Date.now());

  return info.lastInsertRowid;
}

function getWarnings(guildId, userId) {
  return getDb()
    .prepare(
      `SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC`
    )
    .all(guildId, userId);
}

function deleteGuildData(guildId) {
  getDb().prepare('DELETE FROM guild_settings WHERE guild_id = ?').run(guildId);
  getDb().prepare('DELETE FROM warnings WHERE guild_id = ?').run(guildId);
}

module.exports = {
  initDatabase,
  getGuildSettings,
  upsertGuildSettings,
  addWarning,
  getWarnings,
  deleteGuildData,
};
