require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.DISCORD_CLIENT_ID,
  devGuildId: process.env.DEV_GUILD_ID || null,
  apiSecret: process.env.API_SECRET || 'cambia_questa_chiave_segreta',
  apiPort: Number(process.env.API_PORT) || 3001,
  databasePath: process.env.DATABASE_PATH || './data/tmg.sqlite',
  brand: {
    name: 'TMG',
    color: 0xffb020,
    dangerColor: 0xe5484d,
    okColor: 0x3ecf8e,
  },
};
