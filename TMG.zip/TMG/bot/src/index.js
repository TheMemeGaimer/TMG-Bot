const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const config = require('./config');
const { loadCommands } = require('./handlers/loadCommands');
const { loadEvents } = require('./handlers/loadEvents');
const { initDatabase } = require('./utils/database');
const { startApiServer } = require('./api/server');

if (!config.token || !config.clientId) {
  console.error('❌ Manca DISCORD_TOKEN o DISCORD_CLIENT_ID: copia .env.example in .env e compilalo.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
});

client.commands = new Collection();

initDatabase();
loadCommands(client);
loadEvents(client);
startApiServer(client);

client.login(config.token);

process.on('unhandledRejection', (err) => {
  console.error('[unhandledRejection]', err);
});
