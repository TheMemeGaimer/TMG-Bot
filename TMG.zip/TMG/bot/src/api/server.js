const express = require('express');
const cors = require('cors');
const config = require('../config');
const { getGuildSettings, upsertGuildSettings } = require('../utils/database');

/**
 * Piccola API REST interna che il sito Next.js chiama (lato server, mai dal
 * browser) per leggere/scrivere le impostazioni di una guild e per ottenere
 * la lista di canali/ruoli da mostrare nella dashboard.
 */
function startApiServer(client) {
  const app = express();
  app.use(cors());
  app.use(express.json());

  // Autenticazione semplice con chiave condivisa tra bot e sito.
  app.use((req, res, next) => {
    const key = req.header('x-api-key');
    if (key !== config.apiSecret) {
      return res.status(401).json({ error: 'API key mancante o non valida.' });
    }
    next();
  });

  app.get('/stats', (req, res) => {
    res.json({
      guildCount: client.guilds.cache.size,
      userCount: client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0),
      ping: client.ws.ping,
      uptimeSeconds: Math.floor(client.uptime / 1000),
    });
  });

  // Elenco degli ID dei server in cui il bot è presente (usato dal sito per
  // capire quali server dell'utente loggato può gestire).
  app.get('/guilds', (req, res) => {
    const guilds = client.guilds.cache.map((g) => ({
      id: g.id,
      name: g.name,
      icon: g.iconURL(),
      memberCount: g.memberCount,
    }));
    res.json(guilds);
  });

  // Metadati di una guild (canali testuali e ruoli) per popolare i menu a
  // tendina della dashboard.
  app.get('/guilds/:guildId/meta', async (req, res) => {
    const guild = client.guilds.cache.get(req.params.guildId);
    if (!guild) return res.status(404).json({ error: 'Il bot non è in questo server.' });

    const channels = guild.channels.cache
      .filter((c) => c.isTextBased() && !c.isThread())
      .map((c) => ({ id: c.id, name: c.name }));

    const roles = guild.roles.cache
      .filter((r) => !r.managed && r.id !== guild.id)
      .map((r) => ({ id: r.id, name: r.name }));

    res.json({ id: guild.id, name: guild.name, channels, roles });
  });

  app.get('/guilds/:guildId/settings', (req, res) => {
    res.json(getGuildSettings(req.params.guildId));
  });

  app.post('/guilds/:guildId/settings', (req, res) => {
    const updated = upsertGuildSettings(req.params.guildId, {
      log_channel_id: req.body.log_channel_id ?? null,
      welcome_channel_id: req.body.welcome_channel_id ?? null,
      welcome_message: req.body.welcome_message ?? null,
      mute_role_id: req.body.mute_role_id ?? null,
    });
    res.json(updated);
  });

  app.listen(config.apiPort, () => {
    console.log(`[api] API interna in ascolto su http://localhost:${config.apiPort}`);
  });
}

module.exports = { startApiServer };
