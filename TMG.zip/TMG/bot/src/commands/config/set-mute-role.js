const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { upsertGuildSettings } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-mute-role')
    .setDescription('Imposta un ruolo "mutato" di riserva (oltre al timeout nativo di Discord)')
    .addRoleOption((opt) =>
      opt.setName('ruolo').setDescription('Ruolo da usare per i mute manuali').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const role = interaction.options.getRole('ruolo', true);
    upsertGuildSettings(interaction.guild.id, { mute_role_id: role.id });

    await interaction.reply({
      content: `✅ Ruolo mute impostato su ${role}.`,
      ephemeral: true,
    });
  },
};
