const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { upsertGuildSettings } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-welcome')
    .setDescription('Imposta il canale e il messaggio di benvenuto')
    .addChannelOption((opt) =>
      opt
        .setName('canale')
        .setDescription('Canale di benvenuto')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName('messaggio')
        .setDescription('Usa {utente} per menzionare il nuovo membro')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const channel = interaction.options.getChannel('canale', true);
    const message = interaction.options.getString('messaggio');

    upsertGuildSettings(interaction.guild.id, {
      welcome_channel_id: channel.id,
      welcome_message: message || 'Benvenuto/a {utente}! 👋',
    });

    await interaction.reply({
      content: `✅ Messaggio di benvenuto impostato su ${channel}.`,
      ephemeral: true,
    });
  },
};
