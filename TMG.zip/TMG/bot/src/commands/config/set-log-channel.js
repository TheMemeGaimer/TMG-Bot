const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { upsertGuildSettings } = require('../../utils/database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('set-log-channel')
    .setDescription('Imposta il canale dove TMG scrive i log di moderazione')
    .addChannelOption((opt) =>
      opt
        .setName('canale')
        .setDescription('Canale di log')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const channel = interaction.options.getChannel('canale', true);
    upsertGuildSettings(interaction.guild.id, { log_channel_id: channel.id });

    await interaction.reply({
      content: `✅ Canale di log impostato su ${channel}. Puoi cambiarlo in ogni momento anche dalla dashboard web.`,
      ephemeral: true,
    });
  },
};
