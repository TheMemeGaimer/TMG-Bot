const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getGuildSettings } = require('../../utils/database');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('settings')
    .setDescription('Mostra la configurazione attuale di TMG per questo server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    const s = getGuildSettings(interaction.guild.id);

    const embed = new EmbedBuilder()
      .setTitle('Impostazioni di TMG')
      .setColor(config.brand.color)
      .setFooter({ text: 'Modificabili anche dalla dashboard web' })
      .addFields(
        { name: 'Canale log', value: s.log_channel_id ? `<#${s.log_channel_id}>` : 'Non impostato' },
        {
          name: 'Canale benvenuto',
          value: s.welcome_channel_id ? `<#${s.welcome_channel_id}>` : 'Non impostato',
        },
        { name: 'Ruolo mute', value: s.mute_role_id ? `<@&${s.mute_role_id}>` : 'Non impostato' }
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
