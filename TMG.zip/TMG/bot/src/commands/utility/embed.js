const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Fa inviare al bot un embed personalizzato')
    .addStringOption((opt) =>
      opt.setName('titolo').setDescription('Titolo dell\'embed').setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName('descrizione').setDescription('Testo dell\'embed').setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName('colore').setDescription('Colore esadecimale, es. #FFB020')
    )
    .addChannelOption((opt) =>
      opt.setName('canale').setDescription('Canale di destinazione (default: canale attuale)')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interaction) {
    const title = interaction.options.getString('titolo', true);
    const description = interaction.options.getString('descrizione', true);
    const colorInput = interaction.options.getString('colore');
    const channel = interaction.options.getChannel('canale') || interaction.channel;

    if (!channel.isTextBased()) {
      return interaction.reply({ content: '⚠️ Devi scegliere un canale testuale.', ephemeral: true });
    }

    let color = 0xffb020;
    if (colorInput && /^#?[0-9A-Fa-f]{6}$/.test(colorInput)) {
      color = parseInt(colorInput.replace('#', ''), 16);
    }

    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(description)
      .setColor(color)
      .setFooter({ text: 'TMG' })
      .setTimestamp();

    try {
      await channel.send({ embeds: [embed] });
      await interaction.reply({ content: `✅ Embed inviato in ${channel}.`, ephemeral: true });
    } catch (err) {
      console.error('[embed]', err);
      await interaction.reply({ content: '❌ Non riesco a scrivere in quel canale.', ephemeral: true });
    }
  },
};
