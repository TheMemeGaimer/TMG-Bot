const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Fa scrivere un messaggio al bot')
    .addStringOption((opt) =>
      opt.setName('messaggio').setDescription('Testo da inviare').setRequired(true)
    )
    .addChannelOption((opt) =>
      opt.setName('canale').setDescription('Canale di destinazione (default: canale attuale)')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interaction) {
    const text = interaction.options.getString('messaggio', true);
    const channel = interaction.options.getChannel('canale') || interaction.channel;

    if (!channel.isTextBased()) {
      return interaction.reply({ content: '⚠️ Devi scegliere un canale testuale.', ephemeral: true });
    }

    try {
      await channel.send(text);
      await interaction.reply({ content: `✅ Messaggio inviato in ${channel}.`, ephemeral: true });
    } catch (err) {
      console.error('[say]', err);
      await interaction.reply({ content: '❌ Non riesco a scrivere in quel canale.', ephemeral: true });
    }
  },
};
