const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('Mostra tutti i comandi di TMG'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('Comandi di TMG')
      .setColor(config.brand.color)
      .setFooter({ text: 'TMG · gestisci il bot anche dalla dashboard web' })
      .setTimestamp()
      .addFields(
        {
          name: 'Moderazione',
          value:
            '`/ban` `/unban` `/kick` `/timeout` `/untimeout` `/warn` `/warnings` `/purge`',
        },
        {
          name: 'Utility',
          value: '`/ping` `/say` `/embed` `/help`',
        },
        {
          name: 'Configurazione',
          value: '`/settings` `/set-log-channel` `/set-welcome` `/set-mute-role`',
        }
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
