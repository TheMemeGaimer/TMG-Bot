const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Controlla la latenza del bot'),

  async execute(interaction) {
    const sent = await interaction.reply({ content: '🏓 Calcolo...', fetchReply: true });
    const latency = sent.createdTimestamp - interaction.createdTimestamp;

    await interaction.editReply(
      `🏓 Pong! Latenza: **${latency}ms** — WebSocket: **${interaction.client.ws.ping}ms**`
    );
  },
};
