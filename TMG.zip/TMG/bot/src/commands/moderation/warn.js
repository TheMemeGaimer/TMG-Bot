const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildModEmbed } = require('../../utils/embeds');
const { addWarning, getWarnings } = require('../../utils/database');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Assegna un avvertimento a un utente')
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Utente da avvertire').setRequired(true)
    )
    .addStringOption((opt) =>
      opt.setName('motivo').setDescription('Motivo dell\'avvertimento').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser('utente', true);
    const reason = interaction.options.getString('motivo', true);

    addWarning(interaction.guild.id, target.id, interaction.user.id, reason);
    const total = getWarnings(interaction.guild.id, target.id).length;

    const embed = buildModEmbed({
      action: '⚠️ Warn',
      target,
      moderator: interaction.user,
      reason,
      color: config.brand.color,
      extra: [{ name: 'Totale avvertimenti', value: `${total}`, inline: true }],
    });

    await interaction.reply({ embeds: [embed] });
    await logAction(interaction.client, interaction.guild.id, embed);
  },
};
