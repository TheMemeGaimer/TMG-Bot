const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildModEmbed } = require('../../utils/embeds');
const config = require('../../config');

const MAX_TIMEOUT_MINUTES = 40320; // 28 giorni, limite imposto da Discord

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Mette in timeout (silenzia temporaneamente) un utente')
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Utente da silenziare').setRequired(true)
    )
    .addIntegerOption((opt) =>
      opt
        .setName('minuti')
        .setDescription('Durata in minuti (max 40320 = 28 giorni)')
        .setMinValue(1)
        .setMaxValue(MAX_TIMEOUT_MINUTES)
        .setRequired(true)
    )
    .addStringOption((opt) => opt.setName('motivo').setDescription('Motivo del timeout'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser('utente', true);
    const minutes = interaction.options.getInteger('minuti', true);
    const reason = interaction.options.getString('motivo') || 'Nessun motivo specificato';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '⚠️ Utente non trovato nel server.', ephemeral: true });
    }

    if (!member.moderatable) {
      return interaction.reply({
        content: '⚠️ Non posso silenziare questo utente: ha un ruolo pari o superiore al mio.',
        ephemeral: true,
      });
    }

    try {
      await member.timeout(minutes * 60 * 1000, `${reason} — richiesto da ${interaction.user.tag}`);

      const embed = buildModEmbed({
        action: '🔇 Timeout',
        target,
        moderator: interaction.user,
        reason,
        color: config.brand.color,
        extra: [{ name: 'Durata', value: `${minutes} minuti`, inline: true }],
      });

      await interaction.reply({ embeds: [embed] });
      await logAction(interaction.client, interaction.guild.id, embed);
    } catch (err) {
      console.error('[timeout]', err);
      await interaction.reply({ content: '❌ Errore durante il timeout.', ephemeral: true });
    }
  },
};
