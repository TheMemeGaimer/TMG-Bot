const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildModEmbed } = require('../../utils/embeds');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Banna un utente dal server')
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Utente da bannare').setRequired(true)
    )
    .addStringOption((opt) => opt.setName('motivo').setDescription('Motivo del ban'))
    .addIntegerOption((opt) =>
      opt
        .setName('giorni_messaggi')
        .setDescription('Giorni di messaggi da eliminare (0-7)')
        .setMinValue(0)
        .setMaxValue(7)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser('utente', true);
    const reason = interaction.options.getString('motivo') || 'Nessun motivo specificato';
    const deleteDays = interaction.options.getInteger('giorni_messaggi') || 0;
    const member = interaction.guild.members.cache.get(target.id);

    if (member && !member.bannable) {
      return interaction.reply({
        content: '⚠️ Non posso bannare questo utente: ha un ruolo pari o superiore al mio.',
        ephemeral: true,
      });
    }

    try {
      await interaction.guild.members.ban(target.id, {
        deleteMessageSeconds: deleteDays * 24 * 60 * 60,
        reason: `${reason} — richiesto da ${interaction.user.tag}`,
      });

      const embed = buildModEmbed({
        action: '🔨 Ban',
        target,
        moderator: interaction.user,
        reason,
        color: config.brand.dangerColor,
      });

      await interaction.reply({ embeds: [embed] });
      await logAction(interaction.client, interaction.guild.id, embed);
    } catch (err) {
      console.error('[ban]', err);
      await interaction.reply({ content: '❌ Errore durante il ban.', ephemeral: true });
    }
  },
};
