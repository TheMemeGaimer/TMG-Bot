const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildModEmbed } = require('../../utils/embeds');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Rimuove il ban a un utente')
    .addStringOption((opt) =>
      opt.setName('id_utente').setDescription('ID Discord dell\'utente da sbannare').setRequired(true)
    )
    .addStringOption((opt) => opt.setName('motivo').setDescription('Motivo dello sban'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const userId = interaction.options.getString('id_utente', true);
    const reason = interaction.options.getString('motivo') || 'Nessun motivo specificato';

    try {
      const user = await interaction.client.users.fetch(userId);
      await interaction.guild.members.unban(userId, reason);

      const embed = buildModEmbed({
        action: '♻️ Unban',
        target: user,
        moderator: interaction.user,
        reason,
        color: config.brand.okColor,
      });

      await interaction.reply({ embeds: [embed] });
      await logAction(interaction.client, interaction.guild.id, embed);
    } catch (err) {
      console.error('[unban]', err);
      await interaction.reply({
        content: '❌ Impossibile sbannare: controlla che l\'ID sia corretto e che l\'utente sia bannato.',
        ephemeral: true,
      });
    }
  },
};
