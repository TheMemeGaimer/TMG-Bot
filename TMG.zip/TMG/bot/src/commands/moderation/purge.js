const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildLogEmbed } = require('../../utils/embeds');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Elimina in blocco gli ultimi messaggi del canale')
    .addIntegerOption((opt) =>
      opt
        .setName('quantita')
        .setDescription('Numero di messaggi da eliminare (1-100)')
        .setMinValue(1)
        .setMaxValue(100)
        .setRequired(true)
    )
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Elimina solo i messaggi di questo utente')
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interaction) {
    const amount = interaction.options.getInteger('quantita', true);
    const targetUser = interaction.options.getUser('utente');

    await interaction.deferReply({ ephemeral: true });

    try {
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      const filtered = targetUser
        ? messages.filter((m) => m.author.id === targetUser.id).first(amount)
        : messages.first(amount);

      const deleted = await interaction.channel.bulkDelete(filtered, true);

      await interaction.editReply(`🧹 Eliminati ${deleted.size} messaggi.`);

      const embed = buildLogEmbed({
        title: '🧹 Purge',
        color: config.brand.color,
        fields: [
          { name: 'Canale', value: `${interaction.channel}`, inline: true },
          { name: 'Messaggi eliminati', value: `${deleted.size}`, inline: true },
          { name: 'Moderatore', value: `${interaction.user}`, inline: true },
          ...(targetUser ? [{ name: 'Filtro utente', value: `${targetUser}`, inline: true }] : []),
        ],
      });

      await logAction(interaction.client, interaction.guild.id, embed);
    } catch (err) {
      console.error('[purge]', err);
      await interaction.editReply(
        '❌ Errore durante l\'eliminazione (i messaggi più vecchi di 14 giorni non possono essere eliminati in blocco).'
      );
    }
  },
};
