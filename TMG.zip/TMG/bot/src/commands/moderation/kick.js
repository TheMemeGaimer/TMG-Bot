const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildModEmbed } = require('../../utils/embeds');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Espelle un utente dal server')
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Utente da espellere').setRequired(true)
    )
    .addStringOption((opt) => opt.setName('motivo').setDescription('Motivo dell\'espulsione'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser('utente', true);
    const reason = interaction.options.getString('motivo') || 'Nessun motivo specificato';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '⚠️ Utente non trovato nel server.', ephemeral: true });
    }

    if (!member.kickable) {
      return interaction.reply({
        content: '⚠️ Non posso espellere questo utente: ha un ruolo pari o superiore al mio.',
        ephemeral: true,
      });
    }

    try {
      await member.kick(`${reason} — richiesto da ${interaction.user.tag}`);

      const embed = buildModEmbed({
        action: '👢 Kick',
        target,
        moderator: interaction.user,
        reason,
        color: config.brand.dangerColor,
      });

      await interaction.reply({ embeds: [embed] });
      await logAction(interaction.client, interaction.guild.id, embed);
    } catch (err) {
      console.error('[kick]', err);
      await interaction.reply({ content: '❌ Errore durante l\'espulsione.', ephemeral: true });
    }
  },
};
