const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getWarnings } = require('../../utils/database');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Mostra gli avvertimenti di un utente')
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Utente da controllare').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser('utente', true);
    const warnings = getWarnings(interaction.guild.id, target.id);

    if (warnings.length === 0) {
      return interaction.reply({
        content: `✅ ${target} non ha avvertimenti.`,
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setTitle(`Avvertimenti di ${target.tag}`)
      .setColor(config.brand.color)
      .setFooter({ text: 'TMG' })
      .setTimestamp();

    warnings.slice(0, 10).forEach((w, i) => {
      embed.addFields({
        name: `#${i + 1} — ${new Date(w.created_at).toLocaleDateString('it-IT')}`,
        value: `${w.reason}\n_da <@${w.moderator_id}>_`,
      });
    });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
