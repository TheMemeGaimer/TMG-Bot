const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../../utils/logger');
const { buildModEmbed } = require('../../utils/embeds');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Rimuove il timeout da un utente')
    .addUserOption((opt) =>
      opt.setName('utente').setDescription('Utente da riattivare').setRequired(true)
    )
    .addStringOption((opt) => opt.setName('motivo').setDescription('Motivo'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interaction) {
    const target = interaction.options.getUser('utente', true);
    const reason = interaction.options.getString('motivo') || 'Nessun motivo specificato';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) {
      return interaction.reply({ content: '⚠️ Utente non trovato nel server.', ephemeral: true });
    }

    try {
      await member.timeout(null, `${reason} — richiesto da ${interaction.user.tag}`);

      const embed = buildModEmbed({
        action: '🔊 Fine timeout',
        target,
        moderator: interaction.user,
        reason,
        color: config.brand.okColor,
      });

      await interaction.reply({ embeds: [embed] });
      await logAction(interaction.client, interaction.guild.id, embed);
    } catch (err) {
      console.error('[untimeout]', err);
      await interaction.reply({ content: '❌ Errore durante la rimozione del timeout.', ephemeral: true });
    }
  },
};
