const fs = require('node:fs');
const path = require('node:path');

/**
 * Legge ricorsivamente tutte le cartelle dentro src/commands e registra
 * ogni comando nella Collection client.commands.
 */
function loadCommands(client) {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath);
  let count = 0;

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    const files = fs.readdirSync(categoryPath).filter((f) => f.endsWith('.js'));

    for (const file of files) {
      const command = require(path.join(categoryPath, file));

      if (!command?.data || !command?.execute) {
        console.warn(`[commands] ${file} non è valido: manca "data" o "execute".`);
        continue;
      }

      client.commands.set(command.data.name, command);
      count += 1;
    }
  }

  console.log(`[commands] caricati ${count} comandi.`);
}

module.exports = { loadCommands };
