const { deleteGuildData } = require('../utils/database');

module.exports = {
  name: 'guildDelete',
  execute(guild) {
    console.log(`[guildDelete] TMG è stato rimosso dal server "${guild.name}" (${guild.id}).`);
    deleteGuildData(guild.id);
  },
};
