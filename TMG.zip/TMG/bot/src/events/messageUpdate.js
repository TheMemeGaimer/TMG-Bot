const { logAction } = require('../utils/logger');
const { buildLogEmbed } = require('../utils/embeds');
const config = require('../config');

module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;

    const embed = buildLogEmbed({
      title: '✏️ Messaggio modificato',
      color: config.brand.color,
      fields: [
        { name: 'Autore', value: `${newMessage.author}`, inline: true },
        { name: 'Canale', value: `${newMessage.channel}`, inline: true },
        { name: 'Prima', value: oldMessage.content?.slice(0, 500) || '*(vuoto)*' },
        { name: 'Dopo', value: newMessage.content?.slice(0, 500) || '*(vuoto)*' },
      ],
    });

    await logAction(newMessage.client, newMessage.guild.id, embed);
  },
};
