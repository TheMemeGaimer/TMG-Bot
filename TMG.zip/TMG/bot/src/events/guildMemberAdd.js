const { getGuildSettings } = require('../utils/database');
const { logAction } = require('../utils/logger');
const { buildLogEmbed } = require('../utils/embeds');
const config = require('../config');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const settings = getGuildSettings(member.guild.id);

    if (settings.welcome_channel_id) {
      try {
        const channel = await member.client.channels.fetch(settings.welcome_channel_id);
        const text = (settings.welcome_message || 'Benvenuto/a {utente}! 👋').replace(
          '{utente}',
          `${member}`
        );
        if (channel?.isTextBased()) await channel.send(text);
      } catch (err) {
        console.warn('[guildMemberAdd] impossibile inviare il messaggio di benvenuto:', err.message);
      }
    }

    const embed = buildLogEmbed({
      title: '📥 Nuovo membro',
      description: `${member} ha effettuato l'accesso al server.`,
      color: config.brand.okColor,
      fields: [{ name: 'Account creato', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>` }],
    });

    await logAction(member.client, member.guild.id, embed);
  },
};
