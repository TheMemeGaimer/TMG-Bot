const { logAction } = require('../utils/logger');
const { buildLogEmbed } = require('../utils/embeds');
const config = require('../config');

module.exports = {
  name: 'messageDelete',
  async execute(message) {
    if (!message.guild || message.author?.bot) return;

    const embed = buildLogEmbed({
      title: '🗑️ Messaggio eliminato',
      color: config.brand.dangerColor,
      fields: [
        { name: 'Autore', value: `${message.author ?? 'Sconosciuto'}`, inline: true },
        { name: 'Canale', value: `${message.channel}`, inline: true },
        { name: 'Contenuto', value: message.content?.slice(0, 1000) || '*(nessun testo, es. allegato)*' },
      ],
    });

    await logAction(message.client, message.guild.id, embed);
  },
};
