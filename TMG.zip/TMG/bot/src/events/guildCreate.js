module.exports = {
  name: 'guildCreate',
  execute(guild) {
    console.log(`[guildCreate] TMG è stato aggiunto al server "${guild.name}" (${guild.id}).`);
  },
};
