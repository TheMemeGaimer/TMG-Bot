const { ActivityType } = require('discord.js');

module.exports = {
  name: 'clientReady',
  once: true,
  execute(client) {
    console.log(`✅ TMG connesso come ${client.user.tag} — attivo su ${client.guilds.cache.size} server.`);

    client.user.setPresence({
      activities: [{ name: '/help · dashboard su tmg.example.com', type: ActivityType.Watching }],
      status: 'online',
    });
  },
};
