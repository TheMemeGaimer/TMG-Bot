const { logAction } = require('../utils/logger');
const { buildLogEmbed } = require('../utils/embeds');
const config = require('../config');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    const embed = buildLogEmbed({
      title: '📤 Membro uscito',
      description: `${member.user?.tag ?? 'Un utente'} ha lasciato il server.`,
      color: config.brand.dangerColor,
    });

    await logAction(member.client, member.guild.id, embed);
  },
};
