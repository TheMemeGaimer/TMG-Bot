const { logAction } = require('../utils/logger');
const { buildLogEmbed } = require('../utils/embeds');
const config = require('../config');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {
    const embed = buildLogEmbed({
      title: '🔨 Ban rilevato',
      description: `${ban.user.tag} è stato bannato dal server.`,
      color: config.brand.dangerColor,
    });

    await logAction(ban.client, ban.guild.id, embed);
  },
};
