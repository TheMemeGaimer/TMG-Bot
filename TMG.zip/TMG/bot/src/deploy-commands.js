/**
 * Registra tutti gli slash command su Discord.
 * - Se DEV_GUILD_ID è impostato nel .env: registrazione istantanea su quel server (comodo in sviluppo).
 * - Altrimenti: registrazione globale (ci mette fino a un'ora a propagarsi).
 *
 * Uso: npm run deploy-commands
 */
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { REST, Routes } = require('discord.js');
const config = require('./config');

function collectCommandsJson() {
  const commandsPath = path.join(__dirname, 'commands');
  const categories = fs.readdirSync(commandsPath);
  const commands = [];

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    const files = fs.readdirSync(categoryPath).filter((f) => f.endsWith('.js'));

    for (const file of files) {
      const command = require(path.join(categoryPath, file));
      if (command?.data) commands.push(command.data.toJSON());
    }
  }

  return commands;
}

async function main() {
  if (!config.token || !config.clientId) {
    console.error('❌ Imposta DISCORD_TOKEN e DISCORD_CLIENT_ID nel file .env prima di continuare.');
    process.exit(1);
  }

  const commands = collectCommandsJson();
  const rest = new REST().setToken(config.token);

  const route = config.devGuildId
    ? Routes.applicationGuildCommands(config.clientId, config.devGuildId)
    : Routes.applicationCommands(config.clientId);

  console.log(
    `⏳ Registrazione di ${commands.length} comandi ${config.devGuildId ? `sul server di test ${config.devGuildId}` : 'a livello globale'}...`
  );

  const result = await rest.put(route, { body: commands });
  console.log(`✅ Registrati ${result.length} comandi.`);
}

main().catch((err) => {
  console.error('❌ Errore durante la registrazione dei comandi:', err);
  process.exit(1);
});
